/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import datos.ControladorBD;
import java.util.ArrayList;
import modelo.Banco;
import modelo.Cuenta;

/**
 *
 * @author alumno26
 */
public class Principal {
    public static void main(String[] args){
        ControladorBD con= new ControladorBD();
        ArrayList<Cuenta> cuentas= new ArrayList();
        Cuenta cuenta= new Cuenta("1228", "Arturo Castro", 500, "XOC");
        Banco ban= new Banco();
        
        System.out.println(con.conectar());//*************************
        
        //con.agregarCuenta(cuenta);
//con.eliminarCuenta("0000");
//        con.actualizarSucursal("0000", "CUA");
    

        cuentas=con.consultarCuentas();
        for(int i=0; i<cuentas.size(); i++){
            System.out.println(cuentas.get(i));
        }
        ban.setCuentas(cuentas);
        
        //redondear
        System.out.println(ban.promedioCuentas());
        System.out.println(ban.masCuentasAbiertas());
        System.out.println(ban.mayorMenorSaldoUsuario());
        
        System.out.println(con.desconectar());//*************************
    }
}
