/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.Cuenta;

/**
 * Esta clase se encarga de realizar las operaciones de la clase Controlador
 * @author German Ulises Soto Arciga
 * @author Luis Javier Reyes Ramirez
 * @author Fernando Fabian España Lopez
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/Connection.html">Interface Connection:Permite establecer la conexion con una base de datos especifica </a> 
 * @version  1.0
 */
public class ControladorBD {
    private static final String USUARIO="root";
    private static final String PSWD="Miramar100";
    private static final String BD="sucursales26";
    private static final String URL="jdbc:mysql://localhost:3306/";
    private Connection conexion;
/**
 * Metodo que permite establecer la conexion con la base de datos
 * @return El estado de conexion con la base de datos 
 * @see <a href= "https://docs.oracle.com/javase/8/docs/api/java/sql/DriverManager.html">Clase DriverManager: Gestiona el conjunto de controladores Java Database Connectivity (JDBC) que están disponibles para que los utilice una aplicación</a>
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/SQLException.html">Clase SQLException: Una excepción que proporciona información sobre un error de acceso a la base de datos u otros errores</a>
 */  
    public boolean conectar(){
        boolean estado=false;        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion= DriverManager.getConnection(URL+BD, USUARIO,PSWD);
            if(conexion!=null)
                estado=true;            
        } catch (ClassNotFoundException ex) {
            System.out.println("Error "+ex.getMessage());
        } catch (SQLException ex1) {
            System.out.println("Error "+ex1.getMessage());
        }
        return estado;
    }
 /**
  * Metodo que permite la desconexion con la base de datos
  * @return El estado de conexion con la base de datos
  * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/SQLException.html">Clase SQLException: Una excepción que proporciona información sobre un error de acceso a la base de datos u otros errores</a>
  */  
    public boolean desconectar(){
        boolean estado=false;
        
        try {
            conexion.close();
            estado=true;
        } catch (SQLException ex) {
            System.out.println("Error "+ex.getMessage());
        }
        return estado;
    }
/**
 * Metodo que permite realizar la cosulta de la inforcacion bancaria de los cuentahabientes
 * @return La informacion bancaria de los cuentahabientes
 * @see <a href= "https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html">Clase ArrayList: Permite almacenar datos en memoria de forma dinamica</a>
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/Statement.html">Interface Statement: Soporta la ejecución de todas las sentencias de SQL</a>
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/SQLException.html">Clase SQLException: Una excepción que proporciona información sobre un error de acceso a la base de datos u otros errores</a>
 */
    public ArrayList<Cuenta> consultarCuentas(){
        ArrayList<Cuenta> cuentas=new ArrayList<>();
        String q="SELECT * FROM cuentas";
        Statement st;
        ResultSet rs;
        
        try {
            st=conexion.createStatement();
            rs=st.executeQuery(q);
            
            while(rs.next()){
                Cuenta cuenta= new Cuenta();
                cuenta.setNumCuenta(rs.getString("numCuenta"));
                cuenta.setNombreCuentahabiente(rs.getString("nombreCuentahabiente"));
                cuenta.setSaldo(rs.getInt("saldo"));
                cuenta.setSucursalApertura(rs.getString("sucursalApertura"));
                cuentas.add(cuenta);
            }            
        } catch (SQLException ex) {
            System.out.println("Error "+ex.getMessage());
        }        
        return cuentas; 
    }
/**
 * Metodo que permite agregar una nueva cuenta al banco
 * @param cuenta La informacion de la nueva cuenta 
 * @return El estado de la ejecucion del metodo
 * 
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/PreparedStatement.html">Interface Prepared Statement: Soporta cualquier sentencia de SQL que contenga o no marcadores de parámetros de entrada</a> 
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/SQLException.html">Clase SQLException: Una excepción que proporciona información sobre un error de acceso a la base de datos u otros errores</a>
 */   
    public boolean agregarCuenta(Cuenta cuenta){
        boolean estado=false;
        Statement st;//Es necesario?
        PreparedStatement ps;
        String q="INSERT INTO cuentas VALUES (?,?,?,?)";
        //
        try {
            ps=conexion.prepareStatement(q);
            ps.setString(1, cuenta.getNumCuenta());
            ps.setString(2, cuenta.getNombreCuentahabiente());
            ps.setInt(3, cuenta.getSaldo());
            ps.setString(4, cuenta.getSucursalApertura());
            ps.execute();
            estado=true;
        } catch (SQLException ex) {
            System.out.println("Error "+ex.getMessage());
        }
        return estado;
    }
/**
 * Metodo que permite eliminar alguna cuenta de la base de datos
 * @param numCuenta El numero de cuenta asociado al cuentahabiente que se desea eliminar
 * @return El estado de la ejecucion del metodo
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/PreparedStatement.html">Interface Prepared Statement: Soporta cualquier sentencia de SQL que contenga o no marcadores de parámetros de entrada</a> 
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/SQLException.html">Clase SQLException: Una excepción que proporciona información sobre un error de acceso a la base de datos u otros errores</a>
 */
    public boolean eliminarCuenta(String numCuenta){
        boolean estado=false;
        //
         PreparedStatement ps;
         String q="DELETE FROM cuentas WHERE numCuenta =?";
        try {
            ps= conexion.prepareStatement(q);
            ps.setString(1,numCuenta);
            ps.execute();
            estado=true;
        } catch (SQLException ex) {
            System.out.println("Error "+ex.getMessage());
        }
        return estado;
    }
/**
 * Metodo que permite actualizar la sucursal a la cual pertenece un cuentahabiente
 * @param numCuenta El numero de ceunta del cuentahabiente
 * @param sucursalApertura La nueva sucursal del cuentahabiente
 * @return El estado de la ejecucion del metodo
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/PreparedStatement.html">Interface Prepared Statement: Soporta cualquier sentencia de SQL que contenga o no marcadores de parámetros de entrada</a> 
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/sql/SQLException.html">Clase SQLException: Una excepción que proporciona información sobre un error de acceso a la base de datos u otros errores</a>
 */ 
    public boolean actualizarSucursal(String numCuenta, String sucursalApertura){
        boolean estado=false;
        //
         PreparedStatement ps;
         String q="UPDATE cuentas SET sucursalApertura = ? WHERE numCuenta = ?";
        try {
            ps= conexion.prepareStatement(q);
            ps.setString(1,sucursalApertura);
            ps.setString(2,numCuenta);
            ps.execute();
            estado=true;
        } catch (SQLException ex) {
            System.out.println("Error "+ex.getMessage());
        }
        return estado;
    }
}
