/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 * Esta clase se encarga de realizar las operaciones de la clase Cuenta del balance requerido
 * @author German Ulises Soto Arciga
 * @author Luis Javier Reyes Ramirez
 * @author Fernando Fabian España Lopez
 * @version  1.0
 */
public class Cuenta {
    private String numCuenta;
    private String nombreCuentahabiente;
    private int saldo;
    private String sucursalApertura;
/**
 * Metodo constructor por omision 
 */
    public Cuenta() {
    }
/**
 * Metodo constructor paramentrizado
 * @param numCuenta El numero de cuenta del cuentahabiente
 * @param nombreCuentahabiente El nombre del cuentahabiente 
 * @param saldo El saldo del cuentahabiente
 * @param sucursalApertura La sucursal a la cual pertenece el cuentahabiente 
 */
    public Cuenta(String numCuenta, String nombreCuentahabiente, int saldo, String sucursalApertura) {
        this.numCuenta = numCuenta;
        this.nombreCuentahabiente = nombreCuentahabiente;
        this.saldo = saldo;
        this.sucursalApertura = sucursalApertura;
    }
/**
 * Metodo de acceso (getter) del atributo numCuenta
 * @return El numero de cuenta del cuentahabiente
 */
    public String getNumCuenta() {
        return numCuenta;
    }
/**
 * Metodo de acceso (setter) del atributo numCuenta
 * @param numCuenta Establece el numero de cuenta del cuentahabiente
 */
    public void setNumCuenta(String numCuenta) {
        this.numCuenta = numCuenta;
    }
/**
 * Metodo de acceso (getter) del atributo nombreCuentahabiente
 * @return El nombre del cuentahabiente
 */
    public String getNombreCuentahabiente() {
        return nombreCuentahabiente;
    }
/**
 * Metodo de acceso (setter) del atributo nombreCuentahabiente
 * @param nombreCuentahabiente Establece el nombre del cuentaHabiente 
 */
    public void setNombreCuentahabiente(String nombreCuentahabiente) {
        this.nombreCuentahabiente = nombreCuentahabiente;
    }
/**
 * Metodo de acceso (getter) del atributo saldo
 * @return El saldo actual del cuentahabiente
 */
    public int getSaldo() {
        return saldo;
    }
/**
 * Metodo de acceso (setter) del atributo saldo
 * @param saldo Establece el saldo actual del cuentahabiente
 */
    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
/**
 * Metodo de acceso (getter) del atributo sucursalApertura
 * @return La sucursal actual a la cual esta asociada la cuenta del cuentahabiente
 */
    public String getSucursalApertura() {
        return sucursalApertura;
    }
/**
 * Metodo de acceso (setter) del atributo sucursalApertura
 * @param sucursalApertura Establece la sucursal actual a la cual esta asociada la cuenta del cuentahabiente
 */
    public void setSucursalApertura(String sucursalApertura) {
        this.sucursalApertura = sucursalApertura;
    }
/**
 * Metodo que sobreescribe al metodo toString de la clase Object 
 * @return una cadena con la representacion de la clase Cuenta
 * @see <a href= "https://docs.oracle.com/javase/10/docs/api/java/lang/Object.html">Clase Object</a> 
 */
    @Override
    public String toString() {
        return numCuenta + " " + nombreCuentahabiente + " " + saldo +
                " " + sucursalApertura;
    }
    
}
