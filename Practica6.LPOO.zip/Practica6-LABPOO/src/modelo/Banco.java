/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import datos.ControladorBD;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Esta clase se encarga de realizar las operaciones de la clase Banco
 * @author German Ulises Soto Arciga
 * @author Luis Javier Reyes Ramirez
 * @author Fernando Fabian España Lopez
 * @version  1.0
 */
public class Banco {
   private ArrayList<Cuenta> cuentas;

/**
 * Metodo constructor por omision
 */
    public Banco() {
    }

/**
 * Metodo constructor parametrizado
 * @param cuentas La informacion bancaria de los cuentahabientes
 * @see <a href= "https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html">Clase ArrayList: Permite almacenar datos en memoria de forma dinamica</a>
 */
    public Banco(ArrayList<Cuenta> cuentas) {
        this.cuentas = cuentas;
    }
    
/**
 * Metodo de acceso (getter) del atributo ArrayList Cuenta
 * @return La informacion de las cuentas de los cuentahabientes
 */
    public ArrayList<Cuenta> getCuentas() {
        return cuentas;
    }
 
/**
 * Metodo de aceso (setter) del atributo ArrayList Cuenta
 * @param cuentas Establece la informacion de las cuentas de los cuentahabientes
 */
    public void setCuentas(ArrayList<Cuenta> cuentas) {
        this.cuentas = cuentas;
    }

/**
 * Metodo que permite calcular el promedio del saldo por cada sucursal   
 * @return El promedio del saldo de todos los cuentahabientes por cada sucursal
 * @see <a href= "https://docs.oracle.com/javase/7/docs/api/java/text/DecimalFormat.html">Clase DecimalFormat:Permite ajustar el numero de decimales deseables de una variable</a>
 */
    public String promedioCuentas(){
        DecimalFormat formato= new DecimalFormat("#.00");
        String respuesta;
        double azc=0,xoc=0, cua=0;
        int contAZC=0, contXOC=0, contCUA=0;
        for(int i=0; i<cuentas.size(); i++)        {
            if(cuentas.get(i).getSucursalApertura().equals("AZC")){
                azc+=cuentas.get(i).getSaldo();
                contAZC++;
            }else if(cuentas.get(i).getSucursalApertura().equals("CUA")){
                    cua+=cuentas.get(i).getSaldo();
                    contCUA++;
            }else{
                xoc+=cuentas.get(i).getSaldo();
                contXOC++;
            }
        }
        respuesta = "AZC: "+formato.format(azc/contAZC)+"\nCUA: "+formato.format(cua/contCUA)+"\nXOC: "+formato.format(xoc/contXOC);
        return respuesta;
    }
 
/**
 * Metodo que permite obtener a la sucursal con el mayor numero de ceuntas abiertas
 * @return La sucursal con el mayor numero de cuentas abiertas
 */
    public String masCuentasAbiertas(){
        String respuesta;
        int contAZC=0, contXOC=0, contCUA=0;
        for(int i=0; i<this.cuentas.size(); i++)        {
            if(this.cuentas.get(i).getSucursalApertura().equals("AZC")){
                contAZC++;
            }else if(cuentas.get(i).getSucursalApertura().equals("CUA")){
                    contCUA++;
            }else{
                contXOC++;
            }
        }
        if(contAZC>contCUA && contAZC>contXOC){
            respuesta ="AZC";
        }else if(contAZC<contCUA && contCUA>contXOC){
            respuesta ="CUA";
        }else if(contXOC<contAZC && contXOC<contCUA){
            respuesta="XOC";
        }else if(contAZC==contCUA || contCUA==contXOC || contXOC==contAZC){
            if(contAZC==contCUA && contCUA==contXOC){
                return "Todas las cuentas estan empatadas con "+contAZC+" cuentas.";
            }else if(contAZC==contCUA){
                return "AZC y CUA estan empatadas con "+contAZC+" cuentas.";
            }else if(contCUA==contXOC){
                return "CUA y XOC estan empatadas con "+contXOC+" cuentas.";
            }else{
                return "XOC Y AZC estan empatadas con "+contAZC+" cuentas.";
            }
        }else{
            return "Error algo salió mal";
        }
        return respuesta;
    }

/**
 * Metodo que permite obtener a la sucursal con el menor saldo 
 * @return Una cadena que corresponde a la sucursal con el menor saldo
 */
    public String menorSaldo(){
        String respuesta;
        int contAZC=0, contXOC=0, contCUA=0;
        for (int i=0; i<this.cuentas.size(); i++) {
            if(this.cuentas.get(i).getSucursalApertura().equals("AZC")){
                contAZC+=this.cuentas.get(i).getSaldo();
        }
            else if(this.cuentas.get(i).getSucursalApertura().equals("CUA")){
                contCUA+=this.cuentas.get(i).getSaldo();
            }
            else{
                contXOC+=this.cuentas.get(i).getSaldo();
            }
        }
        if(contAZC<contCUA && contAZC<contXOC){
            respuesta="AZC";
        }
        else if(contCUA<contAZC && contCUA<contXOC){
            respuesta="CUA";
        }else if(contXOC<contAZC && contXOC<contCUA){
            respuesta="XOC";
        }else if(contAZC==contCUA || contCUA==contXOC || contXOC==contAZC){
            if(contAZC==contCUA && contCUA==contXOC){
                return "Todas las cuentas estan empatadas con "+contAZC+" cuentas.";
            }else if(contAZC==contCUA){
                return "AZC y CUA estan empatadas con "+contAZC+" cuentas.";
            }else if(contCUA==contXOC){
                return "CUA y XOC estan empatadas con "+contXOC+" cuentas.";
            }else{
                return "XOC Y AZC estan empatadas con "+contAZC+" cuentas.";
            }
        }else{
            return "Error algo salió mal";
        }
        return respuesta;
    }
    
 /**
  * Metodo que permite obtener al nombre del cuentahabiente con el mayor y menor saldo respectivamente incluyendo a la sucursal a la cual pertenece 
  * @return El nombre y la sucursal del cuentahabiente con mayor y menor saldo
  */   
    public String mayorMenorSaldoUsuario(){
        String respuesta;
        int mayor=-1;
        int menor=1000000;
        int indice1=0, indice2=0;
        for(int i=0; i<this.cuentas.size();++i){
            if(this.cuentas.get(i).getSaldo()>mayor){
                 mayor=this.cuentas.get(i).getSaldo();
                 indice1=i;
             }  
        }
        for(int i=0; i<this.cuentas.size(); i++){
             if(this.cuentas.get(i).getSaldo()<menor){
                 menor=this.cuentas.get(i).getSaldo();
                 indice2=i;
             }
         }
        String r1= "Mayor saldo: "+this.cuentas.get(indice1).getNombreCuentahabiente()
                    +" ("+this.cuentas.get(indice1).getSucursalApertura()+")";
        String r2= "Menor saldo: "+this.cuentas.get(indice2).getNombreCuentahabiente()
                    +" ("+this.cuentas.get(indice2).getSucursalApertura()+")";
        
        respuesta=r1+"\n"+r2;
        return respuesta;
    }
    
}

/*

public String menorSaldoUsuario(){
         String respuesta="";
         int menor=1000000;
         for(int i=0; i<this.cuentas.size(); i++){
             if(this.cuentas.get(i).getSaldo()<menor){
                 menor=this.cuentas.get(i).getSaldo();
             }
         }
        String aux1=this.cuentas.get(menor).getNombreCuentahabiente();
        String aux2=this.cuentas.get(menor).getSucursalApertura();
        respuesta=aux1+aux2;
      return respuesta;
    }
     
    public String mayorSaldoUsuario(){
        String respuesta="";
        int mayor=-1;
        for(int i=0; i<this.cuentas.size();++i){
            if(this.cuentas.get(i).getSaldo()>mayor){
                 mayor=this.cuentas.get(i).getSaldo();
             }  
        }
        String aux1=this.cuentas.get(mayor).getNombreCuentahabiente();
        String aux2=this.cuentas.get(mayor).getSucursalApertura();
        respuesta=aux1+aux2;
        return respuesta;
    }
*/